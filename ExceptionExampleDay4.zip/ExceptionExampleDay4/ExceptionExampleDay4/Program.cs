﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ExceptionExampleDay4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
           
            try{
               
                int num = Convert.ToInt32(Console.ReadLine());
            if (num < 0)
                Console.WriteLine ("Invalid number");
            else {
                double square =(double) Math.Sqrt(num);
                Console.WriteLine (square);
                 }
            }
                
            catch(IndexOutOfRangeException ex) {
                Console.WriteLine (ex.Message);
            }
            catch(FormatException){
                Console.WriteLine ("Input format should be integer");
            }
            finally{
                Console.WriteLine ("goodbye");
            }
           
            Console.ReadKey();
        }
    

        }
    }

