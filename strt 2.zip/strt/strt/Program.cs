﻿using System;
using System.IO;
using System.Collections;

namespace strt
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			File.Create ("outputFile.text");
			StreamReader objReader = new StreamReader("test.text");
			string sLine = "";
			ArrayList arrText = new ArrayList();

			while (sLine != null)
			{
				sLine = objReader.ReadLine();
				if (sLine != null)
					arrText.Add(sLine);
			}
			objReader.Close();


			arrText.Reverse();

			foreach (string sOutput in arrText) {

				File.AppendAllText ("/Users/minimac-kol1/Projects/strt/strt/bin/Debug/outputFile.txt", sOutput);
				File.AppendAllText ("/Users/minimac-kol1/Projects/strt/strt/bin/Debug/outputFile.txt", "\n");
			}




		}
	}
}
