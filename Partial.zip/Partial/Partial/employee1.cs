﻿using System;

namespace Partial
{
	public partial class employee
	{
		public void sayHello1()
		{
			Console.WriteLine ("Hello world1");
		}
	}
}

